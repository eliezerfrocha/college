package prog5tratamento;

class Validacao extends Exception {
    public Validacao(String mensagem) {
        super(mensagem);
    }
}