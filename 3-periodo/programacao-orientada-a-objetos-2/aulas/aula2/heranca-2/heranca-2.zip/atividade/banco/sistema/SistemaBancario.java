import java.util.Scanner;

class SistemaBancario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Criação da conta
        ContaCorrente contaCorrente = new ContaCorrente("Usuário", 1000.0, 500.0);

        while (true) {
            System.out.println("\n╔══════════════════════════════════════════════════════╗");
            System.out.println("                SISTEMA BANCÁRIO");
            System.out.println("╚══════════════════════════════════════════════════════╝");
            System.out.println("1 - Conta Corrente");
            System.out.println("2 - Conta Poupança");
            System.out.println("3 - Conta Corrente Premium");
            System.out.println("4 - Conta Corrente Empresarial");
            System.out.println("5 - Conta Poupança Estudantil");
            System.out.println("6 - Sair");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    menuContaCorrente(scanner, contaCorrente);
                    break;
                case 2:
                    menuContaPoupanca(scanner, contaCorrente);
                    break;
                case 3:
                    menuContaCorrentePremium(scanner, contaCorrente);
                    break;
                case 4:
                    menuContaCorrenteEmpresarial(scanner, contaCorrente);
                    break;
                case 5:
                    menuContaPoupancaEstudantil(scanner, contaCorrente);
                    break;
                case 6:
                    System.out.println("\nSaindo do sistema... Até logo!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Opção inválida! Tente novamente.");
            }
        }
    }

    public static void menuContaCorrente(Scanner scanner, ContaCorrente contaCorrente) {
        System.out.println("\n╔══════════════════════════════════════════════════════╗");
        System.out.println("              MENU CONTA CORRENTE");
        System.out.println("╚══════════════════════════════════════════════════════╝");
        System.out.println("1 - Depositar");
        System.out.println("2 - Sacar");
        System.out.println("3 - Exibir Saldo");
        System.out.print("Escolha uma opção: ");
        int opcao = scanner.nextInt();

        switch (opcao) {
            case 1:
                System.out.print("Digite o valor para depósito: ");
                double deposito = scanner.nextDouble();
                contaCorrente.depositar(deposito);
                System.out.println("Depósito realizado com sucesso!");
                break;
            case 2:
                System.out.print("Digite o valor para saque: ");
                double saque = scanner.nextDouble();
                if (contaCorrente.sacar(saque)) {
                    System.out.println("Saque realizado com sucesso!");
                } else {
                    System.out.println("Saldo insuficiente!");
                }
                break;
            case 3:
                System.out.println(contaCorrente.exibeSaldo());
                break;
            default:
                System.out.println("Opção inválida! Tente novamente.");
        }
    }

    public static void menuContaPoupanca(Scanner scanner, ContaCorrente contaCorrente) {
        System.out.println("\n╔══════════════════════════════════════════════════════╗");
        System.out.println("               MENU CONTA POUPANÇA");
        System.out.println("╚══════════════════════════════════════════════════════╝");
        System.out.println("1 - Depositar");
        System.out.println("2 - Sacar");
        System.out.println("3 - Aplicar Rendimento");
        System.out.println("4 - Exibir Saldo");
        System.out.print("Escolha uma opção: ");
        int opcao = scanner.nextInt();

        ContaPoupanca contaPoupanca = new ContaPoupanca("Usuário", 1000.0, 5.0);

        switch (opcao) {
            case 1:
                System.out.print("Digite o valor para depósito: ");
                double deposito = scanner.nextDouble();
                contaPoupanca.depositar(deposito);
                System.out.println("Depósito realizado com sucesso!");
                break;
            case 2:
                System.out.print("Digite o valor para saque: ");
                double saque = scanner.nextDouble();
                if (contaPoupanca.sacar(saque)) {
                    System.out.println("Saque realizado com sucesso!");
                } else {
                    System.out.println("Saldo insuficiente!");
                }
                break;
            case 3:
                contaPoupanca.aplicarRendimento();
                System.out.println("Rendimento aplicado com sucesso!");
                break;
            case 4:
                System.out.println(contaPoupanca.exibeSaldo());
                break;
            default:
                System.out.println("Opção inválida! Tente novamente.");
        }
    }

    public static void menuContaCorrentePremium(Scanner scanner, ContaCorrente contaCorrente) {
        System.out.println("\n╔══════════════════════════════════════════════════════╗");
        System.out.println("     MENU CONTA CORRENTE PREMIUM");
        System.out.println("╚══════════════════════════════════════════════════════╝");
        System.out.println("1 - Depositar");
        System.out.println("2 - Sacar");
        System.out.println("3 - Exibir Saldo");
        System.out.println("4 - Exibir Benefício Premium");
        System.out.print("Escolha uma opção: ");
        int opcao = scanner.nextInt();

        ContaCorrentePremium contaPremium = new ContaCorrentePremium("Usuário", 1000.0, 500.0, 5.0);

        switch (opcao) {
            case 1:
                System.out.print("Digite o valor para depósito: ");
                double deposito = scanner.nextDouble();
                contaPremium.depositar(deposito);
                System.out.println("Depósito realizado com sucesso!");
                break;
            case 2:
                System.out.print("Digite o valor para saque: ");
                double saque = scanner.nextDouble();
                if (contaPremium.sacar(saque)) {
                    System.out.println("Saque realizado com sucesso!");
                } else {
                    System.out.println("Saldo insuficiente!");
                }
                break;
            case 3:
                System.out.println(contaPremium.exibeSaldo());
                break;
            case 4:
                System.out.println(contaPremium.exibeBeneficioPremium());
                break;
            default:
                System.out.println("Opção inválida! Tente novamente.");
        }
    }

    public static void menuContaCorrenteEmpresarial(Scanner scanner, ContaCorrente contaCorrente) {
        System.out.println("\n╔══════════════════════════════════════════════════════╗");
        System.out.println("   MENU CONTA CORRENTE EMPRESARIAL");
        System.out.println("╚══════════════════════════════════════════════════════╝");
        System.out.println("1 - Depositar");
        System.out.println("2 - Sacar");
        System.out.println("3 - Exibir Saldo");
        System.out.println("4 - Solicitar Empréstimo");
        System.out.print("Escolha uma opção: ");
        int opcao = scanner.nextInt();

        ContaCorrenteEmpresarial contaEmpresarial = new ContaCorrenteEmpresarial("Usuário", 1000.0, 500.0, 2.0);

        switch (opcao) {
            case 1:
                System.out.print("Digite o valor para depósito: ");
                double deposito = scanner.nextDouble();
                contaEmpresarial.depositar(deposito);
                System.out.println("Depósito realizado com sucesso!");
                break;
            case 2:
                System.out.print("Digite o valor para saque: ");
                double saque = scanner.nextDouble();
                if (contaEmpresarial.sacar(saque)) {
                    System.out.println("Saque realizado com sucesso!");
                } else {
                    System.out.println("Saldo insuficiente!");
                }
                break;
            case 3:
                System.out.println(contaEmpresarial.exibeSaldo());
                break;
            case 4:
                System.out.print("Digite o valor do empréstimo: ");
                double emprestimo = scanner.nextDouble();
                if (contaEmpresarial.solicitaEmprestimo(emprestimo)) {
                    System.out.println("Empréstimo solicitado com sucesso!");
                } else {
                    System.out.println("Empréstimo negado! Valor solicitado ultrapassa limite.");
                }
                break;
            default:
                System.out.println("Opção inválida! Tente novamente.");
        }
    }

    public static void menuContaPoupancaEstudantil(Scanner scanner, ContaCorrente contaCorrente) {
        System.out.println("\n╔══════════════════════════════════════════════════════╗");
        System.out.println("  MENU CONTA POUPANÇA ESTUDANTIL");
        System.out.println("╚══════════════════════════════════════════════════════╝");
        System.out.println("1 - Depositar");
        System.out.println("2 - Sacar");
        System.out.println("3 - Aplicar Rendimento");
        System.out.println("4 - Exibir Saldo");
        System.out.println("5 - Exibir Limite de Isenção");
        System.out.print("Escolha uma opção: ");
        int opcao = scanner.nextInt();

        ContaPoupamcaEstudantil contaEstudantil = new ContaPoupamcaEstudantil("Usuário", 1000.0, 5.0, 100.0);

        switch (opcao) {
            case 1:
                System.out.print("Digite o valor para depósito: ");
                double deposito = scanner.nextDouble();
                contaEstudantil.depositar(deposito);
                System.out.println("Depósito realizado com sucesso!");
                break;
            case 2:
                System.out.print("Digite o valor para saque: ");
                double saque = scanner.nextDouble();
                if (contaEstudantil.sacar(saque)) {
                    System.out.println("Saque realizado com sucesso!");
                } else {
                    System.out.println("Saldo insuficiente!");
                }
                break;
            case 3:
                contaEstudantil.aplicarRendimento();
                System.out.println("Rendimento aplicado com sucesso!");
                break;
            case 4:
                System.out.println(contaEstudantil.exibeSaldo());
                break;
            case 5:
                System.out.println(contaEstudantil.exibeLimiteIsencao());
                break;
            default:
                System.out.println("Opção inválida! Tente novamente.");
        }
    }
}